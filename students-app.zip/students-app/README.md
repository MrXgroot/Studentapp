# Students Table — React App

A full-featured student management dashboard built with React.js.

## Features

- **Student List** — Name, Email, Age, Actions (Edit / Delete)
- **Add Student** — Form with validation (all fields required, valid email)
- **Edit Student** — Pre-filled form with the same validations
- **Delete Student** — Confirmation dialog before removal
- **Simulated loading** — Skeleton screen on initial load + loading spinners on mutations
- **Search / Filter** — Real-time filter by name, email, or age
- **Excel Export** — Downloads currently filtered rows as `.xlsx`
- **Toast notifications** — Feedback on every action
- **Fully responsive** — Works on mobile

## Tech Stack

- React 18 (Create React App)
- `xlsx` library for Excel export
- Pure CSS (no UI frameworks)
- All data in-memory (no backend required)

## Getting Started

```bash
npm install
npm start
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Build for Production

```bash
npm run build
```

## Deploy to Vercel / Netlify

1. Push the project to GitHub
2. Import the repo in [Vercel](https://vercel.com) or [Netlify](https://netlify.com)
3. Use default settings (CRA is auto-detected)
4. Click **Deploy** — done!

## Project Structure

```
src/
  App.js       — All components + logic (single-file for simplicity)
  App.css      — All styles
  index.js     — React entry point
  index.css    — Global styles & CSS variables
public/
  index.html   — HTML shell
```
