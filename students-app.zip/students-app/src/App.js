import React, { useState, useEffect, useCallback } from 'react';
import * as XLSX from 'xlsx';
import './App.css';

// ── Initial seed data ──────────────────────────────────────────────────────────
const SEED_STUDENTS = [
  { id: 1, name: 'Alice Johnson',   email: 'alice@example.com',   age: 21 },
  { id: 2, name: 'Brian Carter',    email: 'brian@example.com',   age: 23 },
  { id: 3, name: 'Clara Nguyen',    email: 'clara@example.com',   age: 20 },
  { id: 4, name: 'David Park',      email: 'david@example.com',   age: 22 },
  { id: 5, name: 'Eva Müller',      email: 'eva@example.com',     age: 24 },
];

let nextId = 6;

// ── Helpers ───────────────────────────────────────────────────────────────────
function validateForm({ name, email, age }) {
  const errors = {};
  if (!name.trim()) errors.name = 'Name is required.';
  else if (name.trim().length < 2) errors.name = 'At least 2 characters.';

  const emailRx = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!email.trim()) errors.email = 'Email is required.';
  else if (!emailRx.test(email.trim())) errors.email = 'Enter a valid email.';

  const ageNum = Number(age);
  if (age === '' || age === null || age === undefined) errors.age = 'Age is required.';
  else if (!Number.isInteger(ageNum) || ageNum < 1 || ageNum > 120) errors.age = 'Enter a valid age (1–120).';

  return errors;
}

function simulate(ms = 700) {
  return new Promise(res => setTimeout(res, ms));
}

// ── Icons ─────────────────────────────────────────────────────────────────────
const Icon = {
  Plus:     () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>,
  Edit:     () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>,
  Trash:    () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4h6v2"/></svg>,
  Download: () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>,
  Search:   () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>,
  Close:    () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>,
  Warn:     () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>,
  User:     () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>,
  Cap:      () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M22 10v6M2 10l10-5 10 5-10 5-10-5z"/><path d="M6 12v5c0 1.657 2.686 3 6 3s6-1.343 6-3v-5"/></svg>,
};

// ── Modal wrapper ─────────────────────────────────────────────────────────────
function Modal({ onClose, children }) {
  useEffect(() => {
    const handler = e => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [onClose]);

  return (
    <div className="modal-backdrop" onClick={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal-box" role="dialog" aria-modal="true">
        {children}
      </div>
    </div>
  );
}

// ── Student Form ──────────────────────────────────────────────────────────────
function StudentForm({ initial, onSubmit, onClose, loading }) {
  const [form, setForm] = useState(initial || { name: '', email: '', age: '' });
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});

  const change = field => e => {
    setForm(f => ({ ...f, [field]: e.target.value }));
    if (touched[field]) {
      const errs = validateForm({ ...form, [field]: e.target.value });
      setErrors(prev => ({ ...prev, [field]: errs[field] }));
    }
  };

  const blur = field => () => {
    setTouched(t => ({ ...t, [field]: true }));
    const errs = validateForm(form);
    setErrors(prev => ({ ...prev, [field]: errs[field] }));
  };

  const handleSubmit = async e => {
    e.preventDefault();
    const errs = validateForm(form);
    if (Object.keys(errs).length) { setErrors(errs); setTouched({ name: true, email: true, age: true }); return; }
    await onSubmit(form);
  };

  const isEdit = !!initial;

  return (
    <div className="form-modal">
      <div className="form-modal-header">
        <h2>{isEdit ? 'Edit Student' : 'Add New Student'}</h2>
        <button className="icon-btn" onClick={onClose} aria-label="Close"><Icon.Close /></button>
      </div>

      <form onSubmit={handleSubmit} noValidate>
        <div className="field-group">
          <label htmlFor="name">Full Name</label>
          <div className={`input-wrap ${errors.name && touched.name ? 'error' : ''}`}>
            <span className="input-icon"><Icon.User /></span>
            <input
              id="name"
              type="text"
              placeholder="e.g. Jane Doe"
              value={form.name}
              onChange={change('name')}
              onBlur={blur('name')}
              autoFocus
            />
          </div>
          {errors.name && touched.name && <span className="field-error">{errors.name}</span>}
        </div>

        <div className="field-group">
          <label htmlFor="email">Email Address</label>
          <div className={`input-wrap ${errors.email && touched.email ? 'error' : ''}`}>
            <span className="input-icon">@</span>
            <input
              id="email"
              type="email"
              placeholder="e.g. jane@example.com"
              value={form.email}
              onChange={change('email')}
              onBlur={blur('email')}
            />
          </div>
          {errors.email && touched.email && <span className="field-error">{errors.email}</span>}
        </div>

        <div className="field-group">
          <label htmlFor="age">Age</label>
          <div className={`input-wrap ${errors.age && touched.age ? 'error' : ''}`}>
            <span className="input-icon">#</span>
            <input
              id="age"
              type="number"
              placeholder="e.g. 20"
              value={form.age}
              onChange={change('age')}
              onBlur={blur('age')}
              min="1"
              max="120"
            />
          </div>
          {errors.age && touched.age && <span className="field-error">{errors.age}</span>}
        </div>

        <div className="form-actions">
          <button type="button" className="btn btn-ghost" onClick={onClose} disabled={loading}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={loading}>
            {loading ? <span className="spinner" /> : null}
            {loading ? (isEdit ? 'Saving…' : 'Adding…') : (isEdit ? 'Save Changes' : 'Add Student')}
          </button>
        </div>
      </form>
    </div>
  );
}

// ── Delete Confirm Dialog ─────────────────────────────────────────────────────
function DeleteDialog({ student, onConfirm, onClose, loading }) {
  return (
    <div className="dialog">
      <div className="dialog-icon warn"><Icon.Warn /></div>
      <h3>Delete Student?</h3>
      <p>Are you sure you want to remove <strong>{student.name}</strong>? This action cannot be undone.</p>
      <div className="form-actions">
        <button className="btn btn-ghost" onClick={onClose} disabled={loading}>Cancel</button>
        <button className="btn btn-danger" onClick={onConfirm} disabled={loading}>
          {loading ? <span className="spinner" /> : <Icon.Trash />}
          {loading ? 'Deleting…' : 'Delete'}
        </button>
      </div>
    </div>
  );
}

// ── Skeleton Row ──────────────────────────────────────────────────────────────
function SkeletonRow() {
  return (
    <tr className="skeleton-row">
      <td><span className="skeleton" style={{ width: '28px', height: '28px', borderRadius: '50%', display: 'inline-block' }} /></td>
      <td><span className="skeleton" style={{ width: '130px' }} /></td>
      <td><span className="skeleton" style={{ width: '170px' }} /></td>
      <td><span className="skeleton" style={{ width: '40px' }} /></td>
      <td><span className="skeleton" style={{ width: '90px' }} /></td>
    </tr>
  );
}

// ── Main App ──────────────────────────────────────────────────────────────────
export default function App() {
  const [students, setStudents] = useState(SEED_STUDENTS);
  const [search, setSearch]     = useState('');
  const [loading, setLoading]   = useState(true);
  const [modal, setModal]       = useState(null); // null | {type:'add'} | {type:'edit',student} | {type:'delete',student}
  const [opLoading, setOpLoading] = useState(false);
  const [toast, setToast]       = useState(null);

  // Simulate initial load
  useEffect(() => {
    simulate(900).then(() => setLoading(false));
  }, []);

  const showToast = useCallback((msg, kind = 'success') => {
    setToast({ msg, kind });
    setTimeout(() => setToast(null), 3200);
  }, []);

  const filtered = students.filter(s =>
    s.name.toLowerCase().includes(search.toLowerCase()) ||
    s.email.toLowerCase().includes(search.toLowerCase()) ||
    String(s.age).includes(search)
  );

  // ── CRUD ────────────────────────────────────────────────────────────────────
  const handleAdd = async form => {
    setOpLoading(true);
    await simulate(700);
    const student = { id: nextId++, name: form.name.trim(), email: form.email.trim(), age: Number(form.age) };
    setStudents(prev => [student, ...prev]);
    setModal(null);
    setOpLoading(false);
    showToast(`${student.name} added successfully!`);
  };

  const handleEdit = async form => {
    setOpLoading(true);
    await simulate(700);
    setStudents(prev => prev.map(s =>
      s.id === modal.student.id
        ? { ...s, name: form.name.trim(), email: form.email.trim(), age: Number(form.age) }
        : s
    ));
    setModal(null);
    setOpLoading(false);
    showToast('Student updated successfully!');
  };

  const handleDelete = async () => {
    setOpLoading(true);
    await simulate(600);
    const name = modal.student.name;
    setStudents(prev => prev.filter(s => s.id !== modal.student.id));
    setModal(null);
    setOpLoading(false);
    showToast(`${name} removed.`, 'info');
  };

  // ── Excel Export ────────────────────────────────────────────────────────────
  const downloadExcel = () => {
    const data = filtered.map(({ name, email, age }) => ({ Name: name, Email: email, Age: age }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Students');
    // column widths
    ws['!cols'] = [{ wch: 22 }, { wch: 28 }, { wch: 8 }];
    XLSX.writeFile(wb, 'students.xlsx');
    showToast(`Exported ${data.length} student${data.length !== 1 ? 's' : ''} to Excel.`);
  };

  // ── Render ──────────────────────────────────────────────────────────────────
  return (
    <div className="app">
      {/* Header */}
      <header className="app-header">
        <div className="header-left">
          <div className="logo-icon"><Icon.Cap /></div>
          <div>
            <h1>Students</h1>
            <span className="header-sub">Management Dashboard</span>
          </div>
        </div>
        <div className="header-stats">
          <div className="stat-chip">
            <span className="stat-num">{students.length}</span>
            <span className="stat-label">Total</span>
          </div>
          {search && (
            <div className="stat-chip accent">
              <span className="stat-num">{filtered.length}</span>
              <span className="stat-label">Filtered</span>
            </div>
          )}
        </div>
      </header>

      {/* Toolbar */}
      <div className="toolbar">
        <div className="search-wrap">
          <span className="search-icon"><Icon.Search /></span>
          <input
            className="search-input"
            type="text"
            placeholder="Search by name, email, or age…"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
          {search && (
            <button className="search-clear" onClick={() => setSearch('')} aria-label="Clear search">
              <Icon.Close />
            </button>
          )}
        </div>
        <div className="toolbar-actions">
          <button className="btn btn-outline" onClick={downloadExcel} title="Export to Excel">
            <Icon.Download />
            <span>Export Excel</span>
          </button>
          <button className="btn btn-primary" onClick={() => setModal({ type: 'add' })}>
            <Icon.Plus />
            <span>Add Student</span>
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="table-wrap">
        <table className="students-table">
          <thead>
            <tr>
              <th style={{ width: 52 }}>#</th>
              <th>Name</th>
              <th>Email</th>
              <th style={{ width: 80 }}>Age</th>
              <th style={{ width: 130, textAlign: 'right' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              Array.from({ length: 5 }).map((_, i) => <SkeletonRow key={i} />)
            ) : filtered.length === 0 ? (
              <tr>
                <td colSpan={5}>
                  <div className="empty-state">
                    <div className="empty-icon"><Icon.User /></div>
                    <p>{search ? 'No students match your search.' : 'No students yet. Add one!'}</p>
                    {search && <button className="btn btn-ghost" onClick={() => setSearch('')}>Clear search</button>}
                  </div>
                </td>
              </tr>
            ) : (
              filtered.map((student, idx) => (
                <tr key={student.id} className="student-row" style={{ animationDelay: `${idx * 40}ms` }}>
                  <td>
                    <span className="avatar">{student.name.charAt(0).toUpperCase()}</span>
                  </td>
                  <td className="td-name">{student.name}</td>
                  <td className="td-email">{student.email}</td>
                  <td><span className="age-badge">{student.age}</span></td>
                  <td>
                    <div className="row-actions">
                      <button
                        className="action-btn edit"
                        title="Edit"
                        onClick={() => setModal({ type: 'edit', student })}
                      ><Icon.Edit /></button>
                      <button
                        className="action-btn delete"
                        title="Delete"
                        onClick={() => setModal({ type: 'delete', student })}
                      ><Icon.Trash /></button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
        {!loading && filtered.length > 0 && (
          <div className="table-footer">
            Showing {filtered.length} of {students.length} student{students.length !== 1 ? 's' : ''}
            {search && <span className="filter-note"> · filtered by "{search}"</span>}
          </div>
        )}
      </div>

      {/* Modals */}
      {modal?.type === 'add' && (
        <Modal onClose={() => setModal(null)}>
          <StudentForm onSubmit={handleAdd} onClose={() => setModal(null)} loading={opLoading} />
        </Modal>
      )}
      {modal?.type === 'edit' && (
        <Modal onClose={() => setModal(null)}>
          <StudentForm
            initial={modal.student}
            onSubmit={handleEdit}
            onClose={() => setModal(null)}
            loading={opLoading}
          />
        </Modal>
      )}
      {modal?.type === 'delete' && (
        <Modal onClose={() => setModal(null)}>
          <DeleteDialog
            student={modal.student}
            onConfirm={handleDelete}
            onClose={() => setModal(null)}
            loading={opLoading}
          />
        </Modal>
      )}

      {/* Toast */}
      {toast && (
        <div className={`toast toast-${toast.kind}`}>
          {toast.msg}
        </div>
      )}
    </div>
  );
}
